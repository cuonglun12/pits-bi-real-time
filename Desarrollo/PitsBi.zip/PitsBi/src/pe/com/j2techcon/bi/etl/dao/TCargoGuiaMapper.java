package pe.com.j2techcon.bi.etl.dao;

import java.util.List;
import org.apache.ibatis.annotations.Param;
import pe.com.j2techcon.bi.etl.domain.TCargoGuia;
import pe.com.j2techcon.bi.etl.domain.TCargoGuiaExample;

public interface TCargoGuiaMapper {
    int countByExample(TCargoGuiaExample example);

    int deleteByExample(TCargoGuiaExample example);

    int deleteByPrimaryKey(Integer carGuiId);

    int insert(TCargoGuia record);

    int insertSelective(TCargoGuia record);

    List<TCargoGuia> selectByExample(TCargoGuiaExample example);

    TCargoGuia selectByPrimaryKey(Integer carGuiId);

    int updateByExampleSelective(@Param("record") TCargoGuia record, @Param("example") TCargoGuiaExample example);

    int updateByExample(@Param("record") TCargoGuia record, @Param("example") TCargoGuiaExample example);

    int updateByPrimaryKeySelective(TCargoGuia record);

    int updateByPrimaryKey(TCargoGuia record);
}