package pe.com.j2techcon.bi.etl.domain;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

public class TCargoGuiaExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public TCargoGuiaExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        protected void addCriterionForJDBCDate(String condition, Date value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            addCriterion(condition, new java.sql.Date(value.getTime()), property);
        }

        protected void addCriterionForJDBCDate(String condition, List<Date> values, String property) {
            if (values == null || values.size() == 0) {
                throw new RuntimeException("Value list for " + property + " cannot be null or empty");
            }
            List<java.sql.Date> dateList = new ArrayList<java.sql.Date>();
            Iterator<Date> iter = values.iterator();
            while (iter.hasNext()) {
                dateList.add(new java.sql.Date(iter.next().getTime()));
            }
            addCriterion(condition, dateList, property);
        }

        protected void addCriterionForJDBCDate(String condition, Date value1, Date value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            addCriterion(condition, new java.sql.Date(value1.getTime()), new java.sql.Date(value2.getTime()), property);
        }

        public Criteria andCarGuiIdIsNull() {
            addCriterion("car_gui_id is null");
            return (Criteria) this;
        }

        public Criteria andCarGuiIdIsNotNull() {
            addCriterion("car_gui_id is not null");
            return (Criteria) this;
        }

        public Criteria andCarGuiIdEqualTo(Integer value) {
            addCriterion("car_gui_id =", value, "carGuiId");
            return (Criteria) this;
        }

        public Criteria andCarGuiIdNotEqualTo(Integer value) {
            addCriterion("car_gui_id <>", value, "carGuiId");
            return (Criteria) this;
        }

        public Criteria andCarGuiIdGreaterThan(Integer value) {
            addCriterion("car_gui_id >", value, "carGuiId");
            return (Criteria) this;
        }

        public Criteria andCarGuiIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("car_gui_id >=", value, "carGuiId");
            return (Criteria) this;
        }

        public Criteria andCarGuiIdLessThan(Integer value) {
            addCriterion("car_gui_id <", value, "carGuiId");
            return (Criteria) this;
        }

        public Criteria andCarGuiIdLessThanOrEqualTo(Integer value) {
            addCriterion("car_gui_id <=", value, "carGuiId");
            return (Criteria) this;
        }

        public Criteria andCarGuiIdIn(List<Integer> values) {
            addCriterion("car_gui_id in", values, "carGuiId");
            return (Criteria) this;
        }

        public Criteria andCarGuiIdNotIn(List<Integer> values) {
            addCriterion("car_gui_id not in", values, "carGuiId");
            return (Criteria) this;
        }

        public Criteria andCarGuiIdBetween(Integer value1, Integer value2) {
            addCriterion("car_gui_id between", value1, value2, "carGuiId");
            return (Criteria) this;
        }

        public Criteria andCarGuiIdNotBetween(Integer value1, Integer value2) {
            addCriterion("car_gui_id not between", value1, value2, "carGuiId");
            return (Criteria) this;
        }

        public Criteria andDespIdIsNull() {
            addCriterion("desp_id is null");
            return (Criteria) this;
        }

        public Criteria andDespIdIsNotNull() {
            addCriterion("desp_id is not null");
            return (Criteria) this;
        }

        public Criteria andDespIdEqualTo(Integer value) {
            addCriterion("desp_id =", value, "despId");
            return (Criteria) this;
        }

        public Criteria andDespIdNotEqualTo(Integer value) {
            addCriterion("desp_id <>", value, "despId");
            return (Criteria) this;
        }

        public Criteria andDespIdGreaterThan(Integer value) {
            addCriterion("desp_id >", value, "despId");
            return (Criteria) this;
        }

        public Criteria andDespIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("desp_id >=", value, "despId");
            return (Criteria) this;
        }

        public Criteria andDespIdLessThan(Integer value) {
            addCriterion("desp_id <", value, "despId");
            return (Criteria) this;
        }

        public Criteria andDespIdLessThanOrEqualTo(Integer value) {
            addCriterion("desp_id <=", value, "despId");
            return (Criteria) this;
        }

        public Criteria andDespIdIn(List<Integer> values) {
            addCriterion("desp_id in", values, "despId");
            return (Criteria) this;
        }

        public Criteria andDespIdNotIn(List<Integer> values) {
            addCriterion("desp_id not in", values, "despId");
            return (Criteria) this;
        }

        public Criteria andDespIdBetween(Integer value1, Integer value2) {
            addCriterion("desp_id between", value1, value2, "despId");
            return (Criteria) this;
        }

        public Criteria andDespIdNotBetween(Integer value1, Integer value2) {
            addCriterion("desp_id not between", value1, value2, "despId");
            return (Criteria) this;
        }

        public Criteria andCargIdIsNull() {
            addCriterion("carg_id is null");
            return (Criteria) this;
        }

        public Criteria andCargIdIsNotNull() {
            addCriterion("carg_id is not null");
            return (Criteria) this;
        }

        public Criteria andCargIdEqualTo(Integer value) {
            addCriterion("carg_id =", value, "cargId");
            return (Criteria) this;
        }

        public Criteria andCargIdNotEqualTo(Integer value) {
            addCriterion("carg_id <>", value, "cargId");
            return (Criteria) this;
        }

        public Criteria andCargIdGreaterThan(Integer value) {
            addCriterion("carg_id >", value, "cargId");
            return (Criteria) this;
        }

        public Criteria andCargIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("carg_id >=", value, "cargId");
            return (Criteria) this;
        }

        public Criteria andCargIdLessThan(Integer value) {
            addCriterion("carg_id <", value, "cargId");
            return (Criteria) this;
        }

        public Criteria andCargIdLessThanOrEqualTo(Integer value) {
            addCriterion("carg_id <=", value, "cargId");
            return (Criteria) this;
        }

        public Criteria andCargIdIn(List<Integer> values) {
            addCriterion("carg_id in", values, "cargId");
            return (Criteria) this;
        }

        public Criteria andCargIdNotIn(List<Integer> values) {
            addCriterion("carg_id not in", values, "cargId");
            return (Criteria) this;
        }

        public Criteria andCargIdBetween(Integer value1, Integer value2) {
            addCriterion("carg_id between", value1, value2, "cargId");
            return (Criteria) this;
        }

        public Criteria andCargIdNotBetween(Integer value1, Integer value2) {
            addCriterion("carg_id not between", value1, value2, "cargId");
            return (Criteria) this;
        }

        public Criteria andCarGuiCodMovIsNull() {
            addCriterion("car_gui_cod_mov is null");
            return (Criteria) this;
        }

        public Criteria andCarGuiCodMovIsNotNull() {
            addCriterion("car_gui_cod_mov is not null");
            return (Criteria) this;
        }

        public Criteria andCarGuiCodMovEqualTo(Integer value) {
            addCriterion("car_gui_cod_mov =", value, "carGuiCodMov");
            return (Criteria) this;
        }

        public Criteria andCarGuiCodMovNotEqualTo(Integer value) {
            addCriterion("car_gui_cod_mov <>", value, "carGuiCodMov");
            return (Criteria) this;
        }

        public Criteria andCarGuiCodMovGreaterThan(Integer value) {
            addCriterion("car_gui_cod_mov >", value, "carGuiCodMov");
            return (Criteria) this;
        }

        public Criteria andCarGuiCodMovGreaterThanOrEqualTo(Integer value) {
            addCriterion("car_gui_cod_mov >=", value, "carGuiCodMov");
            return (Criteria) this;
        }

        public Criteria andCarGuiCodMovLessThan(Integer value) {
            addCriterion("car_gui_cod_mov <", value, "carGuiCodMov");
            return (Criteria) this;
        }

        public Criteria andCarGuiCodMovLessThanOrEqualTo(Integer value) {
            addCriterion("car_gui_cod_mov <=", value, "carGuiCodMov");
            return (Criteria) this;
        }

        public Criteria andCarGuiCodMovIn(List<Integer> values) {
            addCriterion("car_gui_cod_mov in", values, "carGuiCodMov");
            return (Criteria) this;
        }

        public Criteria andCarGuiCodMovNotIn(List<Integer> values) {
            addCriterion("car_gui_cod_mov not in", values, "carGuiCodMov");
            return (Criteria) this;
        }

        public Criteria andCarGuiCodMovBetween(Integer value1, Integer value2) {
            addCriterion("car_gui_cod_mov between", value1, value2, "carGuiCodMov");
            return (Criteria) this;
        }

        public Criteria andCarGuiCodMovNotBetween(Integer value1, Integer value2) {
            addCriterion("car_gui_cod_mov not between", value1, value2, "carGuiCodMov");
            return (Criteria) this;
        }

        public Criteria andCarGuiCodUbiIsNull() {
            addCriterion("car_gui_cod_ubi is null");
            return (Criteria) this;
        }

        public Criteria andCarGuiCodUbiIsNotNull() {
            addCriterion("car_gui_cod_ubi is not null");
            return (Criteria) this;
        }

        public Criteria andCarGuiCodUbiEqualTo(Integer value) {
            addCriterion("car_gui_cod_ubi =", value, "carGuiCodUbi");
            return (Criteria) this;
        }

        public Criteria andCarGuiCodUbiNotEqualTo(Integer value) {
            addCriterion("car_gui_cod_ubi <>", value, "carGuiCodUbi");
            return (Criteria) this;
        }

        public Criteria andCarGuiCodUbiGreaterThan(Integer value) {
            addCriterion("car_gui_cod_ubi >", value, "carGuiCodUbi");
            return (Criteria) this;
        }

        public Criteria andCarGuiCodUbiGreaterThanOrEqualTo(Integer value) {
            addCriterion("car_gui_cod_ubi >=", value, "carGuiCodUbi");
            return (Criteria) this;
        }

        public Criteria andCarGuiCodUbiLessThan(Integer value) {
            addCriterion("car_gui_cod_ubi <", value, "carGuiCodUbi");
            return (Criteria) this;
        }

        public Criteria andCarGuiCodUbiLessThanOrEqualTo(Integer value) {
            addCriterion("car_gui_cod_ubi <=", value, "carGuiCodUbi");
            return (Criteria) this;
        }

        public Criteria andCarGuiCodUbiIn(List<Integer> values) {
            addCriterion("car_gui_cod_ubi in", values, "carGuiCodUbi");
            return (Criteria) this;
        }

        public Criteria andCarGuiCodUbiNotIn(List<Integer> values) {
            addCriterion("car_gui_cod_ubi not in", values, "carGuiCodUbi");
            return (Criteria) this;
        }

        public Criteria andCarGuiCodUbiBetween(Integer value1, Integer value2) {
            addCriterion("car_gui_cod_ubi between", value1, value2, "carGuiCodUbi");
            return (Criteria) this;
        }

        public Criteria andCarGuiCodUbiNotBetween(Integer value1, Integer value2) {
            addCriterion("car_gui_cod_ubi not between", value1, value2, "carGuiCodUbi");
            return (Criteria) this;
        }

        public Criteria andCarGuiCodZonIsNull() {
            addCriterion("car_gui_cod_zon is null");
            return (Criteria) this;
        }

        public Criteria andCarGuiCodZonIsNotNull() {
            addCriterion("car_gui_cod_zon is not null");
            return (Criteria) this;
        }

        public Criteria andCarGuiCodZonEqualTo(Integer value) {
            addCriterion("car_gui_cod_zon =", value, "carGuiCodZon");
            return (Criteria) this;
        }

        public Criteria andCarGuiCodZonNotEqualTo(Integer value) {
            addCriterion("car_gui_cod_zon <>", value, "carGuiCodZon");
            return (Criteria) this;
        }

        public Criteria andCarGuiCodZonGreaterThan(Integer value) {
            addCriterion("car_gui_cod_zon >", value, "carGuiCodZon");
            return (Criteria) this;
        }

        public Criteria andCarGuiCodZonGreaterThanOrEqualTo(Integer value) {
            addCriterion("car_gui_cod_zon >=", value, "carGuiCodZon");
            return (Criteria) this;
        }

        public Criteria andCarGuiCodZonLessThan(Integer value) {
            addCriterion("car_gui_cod_zon <", value, "carGuiCodZon");
            return (Criteria) this;
        }

        public Criteria andCarGuiCodZonLessThanOrEqualTo(Integer value) {
            addCriterion("car_gui_cod_zon <=", value, "carGuiCodZon");
            return (Criteria) this;
        }

        public Criteria andCarGuiCodZonIn(List<Integer> values) {
            addCriterion("car_gui_cod_zon in", values, "carGuiCodZon");
            return (Criteria) this;
        }

        public Criteria andCarGuiCodZonNotIn(List<Integer> values) {
            addCriterion("car_gui_cod_zon not in", values, "carGuiCodZon");
            return (Criteria) this;
        }

        public Criteria andCarGuiCodZonBetween(Integer value1, Integer value2) {
            addCriterion("car_gui_cod_zon between", value1, value2, "carGuiCodZon");
            return (Criteria) this;
        }

        public Criteria andCarGuiCodZonNotBetween(Integer value1, Integer value2) {
            addCriterion("car_gui_cod_zon not between", value1, value2, "carGuiCodZon");
            return (Criteria) this;
        }

        public Criteria andCarGuiCodPosIsNull() {
            addCriterion("car_gui_cod_pos is null");
            return (Criteria) this;
        }

        public Criteria andCarGuiCodPosIsNotNull() {
            addCriterion("car_gui_cod_pos is not null");
            return (Criteria) this;
        }

        public Criteria andCarGuiCodPosEqualTo(Integer value) {
            addCriterion("car_gui_cod_pos =", value, "carGuiCodPos");
            return (Criteria) this;
        }

        public Criteria andCarGuiCodPosNotEqualTo(Integer value) {
            addCriterion("car_gui_cod_pos <>", value, "carGuiCodPos");
            return (Criteria) this;
        }

        public Criteria andCarGuiCodPosGreaterThan(Integer value) {
            addCriterion("car_gui_cod_pos >", value, "carGuiCodPos");
            return (Criteria) this;
        }

        public Criteria andCarGuiCodPosGreaterThanOrEqualTo(Integer value) {
            addCriterion("car_gui_cod_pos >=", value, "carGuiCodPos");
            return (Criteria) this;
        }

        public Criteria andCarGuiCodPosLessThan(Integer value) {
            addCriterion("car_gui_cod_pos <", value, "carGuiCodPos");
            return (Criteria) this;
        }

        public Criteria andCarGuiCodPosLessThanOrEqualTo(Integer value) {
            addCriterion("car_gui_cod_pos <=", value, "carGuiCodPos");
            return (Criteria) this;
        }

        public Criteria andCarGuiCodPosIn(List<Integer> values) {
            addCriterion("car_gui_cod_pos in", values, "carGuiCodPos");
            return (Criteria) this;
        }

        public Criteria andCarGuiCodPosNotIn(List<Integer> values) {
            addCriterion("car_gui_cod_pos not in", values, "carGuiCodPos");
            return (Criteria) this;
        }

        public Criteria andCarGuiCodPosBetween(Integer value1, Integer value2) {
            addCriterion("car_gui_cod_pos between", value1, value2, "carGuiCodPos");
            return (Criteria) this;
        }

        public Criteria andCarGuiCodPosNotBetween(Integer value1, Integer value2) {
            addCriterion("car_gui_cod_pos not between", value1, value2, "carGuiCodPos");
            return (Criteria) this;
        }

        public Criteria andCarGuiCodVerIsNull() {
            addCriterion("car_gui_cod_ver is null");
            return (Criteria) this;
        }

        public Criteria andCarGuiCodVerIsNotNull() {
            addCriterion("car_gui_cod_ver is not null");
            return (Criteria) this;
        }

        public Criteria andCarGuiCodVerEqualTo(Integer value) {
            addCriterion("car_gui_cod_ver =", value, "carGuiCodVer");
            return (Criteria) this;
        }

        public Criteria andCarGuiCodVerNotEqualTo(Integer value) {
            addCriterion("car_gui_cod_ver <>", value, "carGuiCodVer");
            return (Criteria) this;
        }

        public Criteria andCarGuiCodVerGreaterThan(Integer value) {
            addCriterion("car_gui_cod_ver >", value, "carGuiCodVer");
            return (Criteria) this;
        }

        public Criteria andCarGuiCodVerGreaterThanOrEqualTo(Integer value) {
            addCriterion("car_gui_cod_ver >=", value, "carGuiCodVer");
            return (Criteria) this;
        }

        public Criteria andCarGuiCodVerLessThan(Integer value) {
            addCriterion("car_gui_cod_ver <", value, "carGuiCodVer");
            return (Criteria) this;
        }

        public Criteria andCarGuiCodVerLessThanOrEqualTo(Integer value) {
            addCriterion("car_gui_cod_ver <=", value, "carGuiCodVer");
            return (Criteria) this;
        }

        public Criteria andCarGuiCodVerIn(List<Integer> values) {
            addCriterion("car_gui_cod_ver in", values, "carGuiCodVer");
            return (Criteria) this;
        }

        public Criteria andCarGuiCodVerNotIn(List<Integer> values) {
            addCriterion("car_gui_cod_ver not in", values, "carGuiCodVer");
            return (Criteria) this;
        }

        public Criteria andCarGuiCodVerBetween(Integer value1, Integer value2) {
            addCriterion("car_gui_cod_ver between", value1, value2, "carGuiCodVer");
            return (Criteria) this;
        }

        public Criteria andCarGuiCodVerNotBetween(Integer value1, Integer value2) {
            addCriterion("car_gui_cod_ver not between", value1, value2, "carGuiCodVer");
            return (Criteria) this;
        }

        public Criteria andCarGuiDirIsNull() {
            addCriterion("car_gui_dir is null");
            return (Criteria) this;
        }

        public Criteria andCarGuiDirIsNotNull() {
            addCriterion("car_gui_dir is not null");
            return (Criteria) this;
        }

        public Criteria andCarGuiDirEqualTo(String value) {
            addCriterion("car_gui_dir =", value, "carGuiDir");
            return (Criteria) this;
        }

        public Criteria andCarGuiDirNotEqualTo(String value) {
            addCriterion("car_gui_dir <>", value, "carGuiDir");
            return (Criteria) this;
        }

        public Criteria andCarGuiDirGreaterThan(String value) {
            addCriterion("car_gui_dir >", value, "carGuiDir");
            return (Criteria) this;
        }

        public Criteria andCarGuiDirGreaterThanOrEqualTo(String value) {
            addCriterion("car_gui_dir >=", value, "carGuiDir");
            return (Criteria) this;
        }

        public Criteria andCarGuiDirLessThan(String value) {
            addCriterion("car_gui_dir <", value, "carGuiDir");
            return (Criteria) this;
        }

        public Criteria andCarGuiDirLessThanOrEqualTo(String value) {
            addCriterion("car_gui_dir <=", value, "carGuiDir");
            return (Criteria) this;
        }

        public Criteria andCarGuiDirLike(String value) {
            addCriterion("car_gui_dir like", value, "carGuiDir");
            return (Criteria) this;
        }

        public Criteria andCarGuiDirNotLike(String value) {
            addCriterion("car_gui_dir not like", value, "carGuiDir");
            return (Criteria) this;
        }

        public Criteria andCarGuiDirIn(List<String> values) {
            addCriterion("car_gui_dir in", values, "carGuiDir");
            return (Criteria) this;
        }

        public Criteria andCarGuiDirNotIn(List<String> values) {
            addCriterion("car_gui_dir not in", values, "carGuiDir");
            return (Criteria) this;
        }

        public Criteria andCarGuiDirBetween(String value1, String value2) {
            addCriterion("car_gui_dir between", value1, value2, "carGuiDir");
            return (Criteria) this;
        }

        public Criteria andCarGuiDirNotBetween(String value1, String value2) {
            addCriterion("car_gui_dir not between", value1, value2, "carGuiDir");
            return (Criteria) this;
        }

        public Criteria andCarGuiRefIsNull() {
            addCriterion("car_gui_ref is null");
            return (Criteria) this;
        }

        public Criteria andCarGuiRefIsNotNull() {
            addCriterion("car_gui_ref is not null");
            return (Criteria) this;
        }

        public Criteria andCarGuiRefEqualTo(String value) {
            addCriterion("car_gui_ref =", value, "carGuiRef");
            return (Criteria) this;
        }

        public Criteria andCarGuiRefNotEqualTo(String value) {
            addCriterion("car_gui_ref <>", value, "carGuiRef");
            return (Criteria) this;
        }

        public Criteria andCarGuiRefGreaterThan(String value) {
            addCriterion("car_gui_ref >", value, "carGuiRef");
            return (Criteria) this;
        }

        public Criteria andCarGuiRefGreaterThanOrEqualTo(String value) {
            addCriterion("car_gui_ref >=", value, "carGuiRef");
            return (Criteria) this;
        }

        public Criteria andCarGuiRefLessThan(String value) {
            addCriterion("car_gui_ref <", value, "carGuiRef");
            return (Criteria) this;
        }

        public Criteria andCarGuiRefLessThanOrEqualTo(String value) {
            addCriterion("car_gui_ref <=", value, "carGuiRef");
            return (Criteria) this;
        }

        public Criteria andCarGuiRefLike(String value) {
            addCriterion("car_gui_ref like", value, "carGuiRef");
            return (Criteria) this;
        }

        public Criteria andCarGuiRefNotLike(String value) {
            addCriterion("car_gui_ref not like", value, "carGuiRef");
            return (Criteria) this;
        }

        public Criteria andCarGuiRefIn(List<String> values) {
            addCriterion("car_gui_ref in", values, "carGuiRef");
            return (Criteria) this;
        }

        public Criteria andCarGuiRefNotIn(List<String> values) {
            addCriterion("car_gui_ref not in", values, "carGuiRef");
            return (Criteria) this;
        }

        public Criteria andCarGuiRefBetween(String value1, String value2) {
            addCriterion("car_gui_ref between", value1, value2, "carGuiRef");
            return (Criteria) this;
        }

        public Criteria andCarGuiRefNotBetween(String value1, String value2) {
            addCriterion("car_gui_ref not between", value1, value2, "carGuiRef");
            return (Criteria) this;
        }

        public Criteria andCarGuiFecSalIsNull() {
            addCriterion("car_gui_fec_sal is null");
            return (Criteria) this;
        }

        public Criteria andCarGuiFecSalIsNotNull() {
            addCriterion("car_gui_fec_sal is not null");
            return (Criteria) this;
        }

        public Criteria andCarGuiFecSalEqualTo(Date value) {
            addCriterionForJDBCDate("car_gui_fec_sal =", value, "carGuiFecSal");
            return (Criteria) this;
        }

        public Criteria andCarGuiFecSalNotEqualTo(Date value) {
            addCriterionForJDBCDate("car_gui_fec_sal <>", value, "carGuiFecSal");
            return (Criteria) this;
        }

        public Criteria andCarGuiFecSalGreaterThan(Date value) {
            addCriterionForJDBCDate("car_gui_fec_sal >", value, "carGuiFecSal");
            return (Criteria) this;
        }

        public Criteria andCarGuiFecSalGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("car_gui_fec_sal >=", value, "carGuiFecSal");
            return (Criteria) this;
        }

        public Criteria andCarGuiFecSalLessThan(Date value) {
            addCriterionForJDBCDate("car_gui_fec_sal <", value, "carGuiFecSal");
            return (Criteria) this;
        }

        public Criteria andCarGuiFecSalLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("car_gui_fec_sal <=", value, "carGuiFecSal");
            return (Criteria) this;
        }

        public Criteria andCarGuiFecSalIn(List<Date> values) {
            addCriterionForJDBCDate("car_gui_fec_sal in", values, "carGuiFecSal");
            return (Criteria) this;
        }

        public Criteria andCarGuiFecSalNotIn(List<Date> values) {
            addCriterionForJDBCDate("car_gui_fec_sal not in", values, "carGuiFecSal");
            return (Criteria) this;
        }

        public Criteria andCarGuiFecSalBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("car_gui_fec_sal between", value1, value2, "carGuiFecSal");
            return (Criteria) this;
        }

        public Criteria andCarGuiFecSalNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("car_gui_fec_sal not between", value1, value2, "carGuiFecSal");
            return (Criteria) this;
        }

        public Criteria andCarGuiFecRetProIsNull() {
            addCriterion("car_gui_fec_ret_pro is null");
            return (Criteria) this;
        }

        public Criteria andCarGuiFecRetProIsNotNull() {
            addCriterion("car_gui_fec_ret_pro is not null");
            return (Criteria) this;
        }

        public Criteria andCarGuiFecRetProEqualTo(Date value) {
            addCriterionForJDBCDate("car_gui_fec_ret_pro =", value, "carGuiFecRetPro");
            return (Criteria) this;
        }

        public Criteria andCarGuiFecRetProNotEqualTo(Date value) {
            addCriterionForJDBCDate("car_gui_fec_ret_pro <>", value, "carGuiFecRetPro");
            return (Criteria) this;
        }

        public Criteria andCarGuiFecRetProGreaterThan(Date value) {
            addCriterionForJDBCDate("car_gui_fec_ret_pro >", value, "carGuiFecRetPro");
            return (Criteria) this;
        }

        public Criteria andCarGuiFecRetProGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("car_gui_fec_ret_pro >=", value, "carGuiFecRetPro");
            return (Criteria) this;
        }

        public Criteria andCarGuiFecRetProLessThan(Date value) {
            addCriterionForJDBCDate("car_gui_fec_ret_pro <", value, "carGuiFecRetPro");
            return (Criteria) this;
        }

        public Criteria andCarGuiFecRetProLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("car_gui_fec_ret_pro <=", value, "carGuiFecRetPro");
            return (Criteria) this;
        }

        public Criteria andCarGuiFecRetProIn(List<Date> values) {
            addCriterionForJDBCDate("car_gui_fec_ret_pro in", values, "carGuiFecRetPro");
            return (Criteria) this;
        }

        public Criteria andCarGuiFecRetProNotIn(List<Date> values) {
            addCriterionForJDBCDate("car_gui_fec_ret_pro not in", values, "carGuiFecRetPro");
            return (Criteria) this;
        }

        public Criteria andCarGuiFecRetProBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("car_gui_fec_ret_pro between", value1, value2, "carGuiFecRetPro");
            return (Criteria) this;
        }

        public Criteria andCarGuiFecRetProNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("car_gui_fec_ret_pro not between", value1, value2, "carGuiFecRetPro");
            return (Criteria) this;
        }

        public Criteria andCarGuiFecRetReaIsNull() {
            addCriterion("car_gui_fec_ret_rea is null");
            return (Criteria) this;
        }

        public Criteria andCarGuiFecRetReaIsNotNull() {
            addCriterion("car_gui_fec_ret_rea is not null");
            return (Criteria) this;
        }

        public Criteria andCarGuiFecRetReaEqualTo(Date value) {
            addCriterionForJDBCDate("car_gui_fec_ret_rea =", value, "carGuiFecRetRea");
            return (Criteria) this;
        }

        public Criteria andCarGuiFecRetReaNotEqualTo(Date value) {
            addCriterionForJDBCDate("car_gui_fec_ret_rea <>", value, "carGuiFecRetRea");
            return (Criteria) this;
        }

        public Criteria andCarGuiFecRetReaGreaterThan(Date value) {
            addCriterionForJDBCDate("car_gui_fec_ret_rea >", value, "carGuiFecRetRea");
            return (Criteria) this;
        }

        public Criteria andCarGuiFecRetReaGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("car_gui_fec_ret_rea >=", value, "carGuiFecRetRea");
            return (Criteria) this;
        }

        public Criteria andCarGuiFecRetReaLessThan(Date value) {
            addCriterionForJDBCDate("car_gui_fec_ret_rea <", value, "carGuiFecRetRea");
            return (Criteria) this;
        }

        public Criteria andCarGuiFecRetReaLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("car_gui_fec_ret_rea <=", value, "carGuiFecRetRea");
            return (Criteria) this;
        }

        public Criteria andCarGuiFecRetReaIn(List<Date> values) {
            addCriterionForJDBCDate("car_gui_fec_ret_rea in", values, "carGuiFecRetRea");
            return (Criteria) this;
        }

        public Criteria andCarGuiFecRetReaNotIn(List<Date> values) {
            addCriterionForJDBCDate("car_gui_fec_ret_rea not in", values, "carGuiFecRetRea");
            return (Criteria) this;
        }

        public Criteria andCarGuiFecRetReaBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("car_gui_fec_ret_rea between", value1, value2, "carGuiFecRetRea");
            return (Criteria) this;
        }

        public Criteria andCarGuiFecRetReaNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("car_gui_fec_ret_rea not between", value1, value2, "carGuiFecRetRea");
            return (Criteria) this;
        }

        public Criteria andCarGuiFecVerIsNull() {
            addCriterion("car_gui_fec_ver is null");
            return (Criteria) this;
        }

        public Criteria andCarGuiFecVerIsNotNull() {
            addCriterion("car_gui_fec_ver is not null");
            return (Criteria) this;
        }

        public Criteria andCarGuiFecVerEqualTo(Date value) {
            addCriterionForJDBCDate("car_gui_fec_ver =", value, "carGuiFecVer");
            return (Criteria) this;
        }

        public Criteria andCarGuiFecVerNotEqualTo(Date value) {
            addCriterionForJDBCDate("car_gui_fec_ver <>", value, "carGuiFecVer");
            return (Criteria) this;
        }

        public Criteria andCarGuiFecVerGreaterThan(Date value) {
            addCriterionForJDBCDate("car_gui_fec_ver >", value, "carGuiFecVer");
            return (Criteria) this;
        }

        public Criteria andCarGuiFecVerGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("car_gui_fec_ver >=", value, "carGuiFecVer");
            return (Criteria) this;
        }

        public Criteria andCarGuiFecVerLessThan(Date value) {
            addCriterionForJDBCDate("car_gui_fec_ver <", value, "carGuiFecVer");
            return (Criteria) this;
        }

        public Criteria andCarGuiFecVerLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("car_gui_fec_ver <=", value, "carGuiFecVer");
            return (Criteria) this;
        }

        public Criteria andCarGuiFecVerIn(List<Date> values) {
            addCriterionForJDBCDate("car_gui_fec_ver in", values, "carGuiFecVer");
            return (Criteria) this;
        }

        public Criteria andCarGuiFecVerNotIn(List<Date> values) {
            addCriterionForJDBCDate("car_gui_fec_ver not in", values, "carGuiFecVer");
            return (Criteria) this;
        }

        public Criteria andCarGuiFecVerBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("car_gui_fec_ver between", value1, value2, "carGuiFecVer");
            return (Criteria) this;
        }

        public Criteria andCarGuiFecVerNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("car_gui_fec_ver not between", value1, value2, "carGuiFecVer");
            return (Criteria) this;
        }

        public Criteria andCarGuiCodEstIsNull() {
            addCriterion("car_gui_cod_est is null");
            return (Criteria) this;
        }

        public Criteria andCarGuiCodEstIsNotNull() {
            addCriterion("car_gui_cod_est is not null");
            return (Criteria) this;
        }

        public Criteria andCarGuiCodEstEqualTo(Integer value) {
            addCriterion("car_gui_cod_est =", value, "carGuiCodEst");
            return (Criteria) this;
        }

        public Criteria andCarGuiCodEstNotEqualTo(Integer value) {
            addCriterion("car_gui_cod_est <>", value, "carGuiCodEst");
            return (Criteria) this;
        }

        public Criteria andCarGuiCodEstGreaterThan(Integer value) {
            addCriterion("car_gui_cod_est >", value, "carGuiCodEst");
            return (Criteria) this;
        }

        public Criteria andCarGuiCodEstGreaterThanOrEqualTo(Integer value) {
            addCriterion("car_gui_cod_est >=", value, "carGuiCodEst");
            return (Criteria) this;
        }

        public Criteria andCarGuiCodEstLessThan(Integer value) {
            addCriterion("car_gui_cod_est <", value, "carGuiCodEst");
            return (Criteria) this;
        }

        public Criteria andCarGuiCodEstLessThanOrEqualTo(Integer value) {
            addCriterion("car_gui_cod_est <=", value, "carGuiCodEst");
            return (Criteria) this;
        }

        public Criteria andCarGuiCodEstIn(List<Integer> values) {
            addCriterion("car_gui_cod_est in", values, "carGuiCodEst");
            return (Criteria) this;
        }

        public Criteria andCarGuiCodEstNotIn(List<Integer> values) {
            addCriterion("car_gui_cod_est not in", values, "carGuiCodEst");
            return (Criteria) this;
        }

        public Criteria andCarGuiCodEstBetween(Integer value1, Integer value2) {
            addCriterion("car_gui_cod_est between", value1, value2, "carGuiCodEst");
            return (Criteria) this;
        }

        public Criteria andCarGuiCodEstNotBetween(Integer value1, Integer value2) {
            addCriterion("car_gui_cod_est not between", value1, value2, "carGuiCodEst");
            return (Criteria) this;
        }

        public Criteria andFecNumCamIsNull() {
            addCriterion("fec_num_cam is null");
            return (Criteria) this;
        }

        public Criteria andFecNumCamIsNotNull() {
            addCriterion("fec_num_cam is not null");
            return (Criteria) this;
        }

        public Criteria andFecNumCamEqualTo(Integer value) {
            addCriterion("fec_num_cam =", value, "fecNumCam");
            return (Criteria) this;
        }

        public Criteria andFecNumCamNotEqualTo(Integer value) {
            addCriterion("fec_num_cam <>", value, "fecNumCam");
            return (Criteria) this;
        }

        public Criteria andFecNumCamGreaterThan(Integer value) {
            addCriterion("fec_num_cam >", value, "fecNumCam");
            return (Criteria) this;
        }

        public Criteria andFecNumCamGreaterThanOrEqualTo(Integer value) {
            addCriterion("fec_num_cam >=", value, "fecNumCam");
            return (Criteria) this;
        }

        public Criteria andFecNumCamLessThan(Integer value) {
            addCriterion("fec_num_cam <", value, "fecNumCam");
            return (Criteria) this;
        }

        public Criteria andFecNumCamLessThanOrEqualTo(Integer value) {
            addCriterion("fec_num_cam <=", value, "fecNumCam");
            return (Criteria) this;
        }

        public Criteria andFecNumCamIn(List<Integer> values) {
            addCriterion("fec_num_cam in", values, "fecNumCam");
            return (Criteria) this;
        }

        public Criteria andFecNumCamNotIn(List<Integer> values) {
            addCriterion("fec_num_cam not in", values, "fecNumCam");
            return (Criteria) this;
        }

        public Criteria andFecNumCamBetween(Integer value1, Integer value2) {
            addCriterion("fec_num_cam between", value1, value2, "fecNumCam");
            return (Criteria) this;
        }

        public Criteria andFecNumCamNotBetween(Integer value1, Integer value2) {
            addCriterion("fec_num_cam not between", value1, value2, "fecNumCam");
            return (Criteria) this;
        }

        public Criteria andCodIndCamIsNull() {
            addCriterion("cod_ind_cam is null");
            return (Criteria) this;
        }

        public Criteria andCodIndCamIsNotNull() {
            addCriterion("cod_ind_cam is not null");
            return (Criteria) this;
        }

        public Criteria andCodIndCamEqualTo(String value) {
            addCriterion("cod_ind_cam =", value, "codIndCam");
            return (Criteria) this;
        }

        public Criteria andCodIndCamNotEqualTo(String value) {
            addCriterion("cod_ind_cam <>", value, "codIndCam");
            return (Criteria) this;
        }

        public Criteria andCodIndCamGreaterThan(String value) {
            addCriterion("cod_ind_cam >", value, "codIndCam");
            return (Criteria) this;
        }

        public Criteria andCodIndCamGreaterThanOrEqualTo(String value) {
            addCriterion("cod_ind_cam >=", value, "codIndCam");
            return (Criteria) this;
        }

        public Criteria andCodIndCamLessThan(String value) {
            addCriterion("cod_ind_cam <", value, "codIndCam");
            return (Criteria) this;
        }

        public Criteria andCodIndCamLessThanOrEqualTo(String value) {
            addCriterion("cod_ind_cam <=", value, "codIndCam");
            return (Criteria) this;
        }

        public Criteria andCodIndCamLike(String value) {
            addCriterion("cod_ind_cam like", value, "codIndCam");
            return (Criteria) this;
        }

        public Criteria andCodIndCamNotLike(String value) {
            addCriterion("cod_ind_cam not like", value, "codIndCam");
            return (Criteria) this;
        }

        public Criteria andCodIndCamIn(List<String> values) {
            addCriterion("cod_ind_cam in", values, "codIndCam");
            return (Criteria) this;
        }

        public Criteria andCodIndCamNotIn(List<String> values) {
            addCriterion("cod_ind_cam not in", values, "codIndCam");
            return (Criteria) this;
        }

        public Criteria andCodIndCamBetween(String value1, String value2) {
            addCriterion("cod_ind_cam between", value1, value2, "codIndCam");
            return (Criteria) this;
        }

        public Criteria andCodIndCamNotBetween(String value1, String value2) {
            addCriterion("cod_ind_cam not between", value1, value2, "codIndCam");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}