package pe.com.j2techcon.bi.etl.domain;

import java.util.ArrayList;
import java.util.List;

public class TResultadoDespachoExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public TResultadoDespachoExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andResDesIdIsNull() {
            addCriterion("res_des_id is null");
            return (Criteria) this;
        }

        public Criteria andResDesIdIsNotNull() {
            addCriterion("res_des_id is not null");
            return (Criteria) this;
        }

        public Criteria andResDesIdEqualTo(Integer value) {
            addCriterion("res_des_id =", value, "resDesId");
            return (Criteria) this;
        }

        public Criteria andResDesIdNotEqualTo(Integer value) {
            addCriterion("res_des_id <>", value, "resDesId");
            return (Criteria) this;
        }

        public Criteria andResDesIdGreaterThan(Integer value) {
            addCriterion("res_des_id >", value, "resDesId");
            return (Criteria) this;
        }

        public Criteria andResDesIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("res_des_id >=", value, "resDesId");
            return (Criteria) this;
        }

        public Criteria andResDesIdLessThan(Integer value) {
            addCriterion("res_des_id <", value, "resDesId");
            return (Criteria) this;
        }

        public Criteria andResDesIdLessThanOrEqualTo(Integer value) {
            addCriterion("res_des_id <=", value, "resDesId");
            return (Criteria) this;
        }

        public Criteria andResDesIdIn(List<Integer> values) {
            addCriterion("res_des_id in", values, "resDesId");
            return (Criteria) this;
        }

        public Criteria andResDesIdNotIn(List<Integer> values) {
            addCriterion("res_des_id not in", values, "resDesId");
            return (Criteria) this;
        }

        public Criteria andResDesIdBetween(Integer value1, Integer value2) {
            addCriterion("res_des_id between", value1, value2, "resDesId");
            return (Criteria) this;
        }

        public Criteria andResDesIdNotBetween(Integer value1, Integer value2) {
            addCriterion("res_des_id not between", value1, value2, "resDesId");
            return (Criteria) this;
        }

        public Criteria andDespIdIsNull() {
            addCriterion("desp_id is null");
            return (Criteria) this;
        }

        public Criteria andDespIdIsNotNull() {
            addCriterion("desp_id is not null");
            return (Criteria) this;
        }

        public Criteria andDespIdEqualTo(Integer value) {
            addCriterion("desp_id =", value, "despId");
            return (Criteria) this;
        }

        public Criteria andDespIdNotEqualTo(Integer value) {
            addCriterion("desp_id <>", value, "despId");
            return (Criteria) this;
        }

        public Criteria andDespIdGreaterThan(Integer value) {
            addCriterion("desp_id >", value, "despId");
            return (Criteria) this;
        }

        public Criteria andDespIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("desp_id >=", value, "despId");
            return (Criteria) this;
        }

        public Criteria andDespIdLessThan(Integer value) {
            addCriterion("desp_id <", value, "despId");
            return (Criteria) this;
        }

        public Criteria andDespIdLessThanOrEqualTo(Integer value) {
            addCriterion("desp_id <=", value, "despId");
            return (Criteria) this;
        }

        public Criteria andDespIdIn(List<Integer> values) {
            addCriterion("desp_id in", values, "despId");
            return (Criteria) this;
        }

        public Criteria andDespIdNotIn(List<Integer> values) {
            addCriterion("desp_id not in", values, "despId");
            return (Criteria) this;
        }

        public Criteria andDespIdBetween(Integer value1, Integer value2) {
            addCriterion("desp_id between", value1, value2, "despId");
            return (Criteria) this;
        }

        public Criteria andDespIdNotBetween(Integer value1, Integer value2) {
            addCriterion("desp_id not between", value1, value2, "despId");
            return (Criteria) this;
        }

        public Criteria andResDesCodMovIsNull() {
            addCriterion("res_des_cod_mov is null");
            return (Criteria) this;
        }

        public Criteria andResDesCodMovIsNotNull() {
            addCriterion("res_des_cod_mov is not null");
            return (Criteria) this;
        }

        public Criteria andResDesCodMovEqualTo(Integer value) {
            addCriterion("res_des_cod_mov =", value, "resDesCodMov");
            return (Criteria) this;
        }

        public Criteria andResDesCodMovNotEqualTo(Integer value) {
            addCriterion("res_des_cod_mov <>", value, "resDesCodMov");
            return (Criteria) this;
        }

        public Criteria andResDesCodMovGreaterThan(Integer value) {
            addCriterion("res_des_cod_mov >", value, "resDesCodMov");
            return (Criteria) this;
        }

        public Criteria andResDesCodMovGreaterThanOrEqualTo(Integer value) {
            addCriterion("res_des_cod_mov >=", value, "resDesCodMov");
            return (Criteria) this;
        }

        public Criteria andResDesCodMovLessThan(Integer value) {
            addCriterion("res_des_cod_mov <", value, "resDesCodMov");
            return (Criteria) this;
        }

        public Criteria andResDesCodMovLessThanOrEqualTo(Integer value) {
            addCriterion("res_des_cod_mov <=", value, "resDesCodMov");
            return (Criteria) this;
        }

        public Criteria andResDesCodMovIn(List<Integer> values) {
            addCriterion("res_des_cod_mov in", values, "resDesCodMov");
            return (Criteria) this;
        }

        public Criteria andResDesCodMovNotIn(List<Integer> values) {
            addCriterion("res_des_cod_mov not in", values, "resDesCodMov");
            return (Criteria) this;
        }

        public Criteria andResDesCodMovBetween(Integer value1, Integer value2) {
            addCriterion("res_des_cod_mov between", value1, value2, "resDesCodMov");
            return (Criteria) this;
        }

        public Criteria andResDesCodMovNotBetween(Integer value1, Integer value2) {
            addCriterion("res_des_cod_mov not between", value1, value2, "resDesCodMov");
            return (Criteria) this;
        }

        public Criteria andResDesNumCargosIsNull() {
            addCriterion("res_des_num_cargos is null");
            return (Criteria) this;
        }

        public Criteria andResDesNumCargosIsNotNull() {
            addCriterion("res_des_num_cargos is not null");
            return (Criteria) this;
        }

        public Criteria andResDesNumCargosEqualTo(Integer value) {
            addCriterion("res_des_num_cargos =", value, "resDesNumCargos");
            return (Criteria) this;
        }

        public Criteria andResDesNumCargosNotEqualTo(Integer value) {
            addCriterion("res_des_num_cargos <>", value, "resDesNumCargos");
            return (Criteria) this;
        }

        public Criteria andResDesNumCargosGreaterThan(Integer value) {
            addCriterion("res_des_num_cargos >", value, "resDesNumCargos");
            return (Criteria) this;
        }

        public Criteria andResDesNumCargosGreaterThanOrEqualTo(Integer value) {
            addCriterion("res_des_num_cargos >=", value, "resDesNumCargos");
            return (Criteria) this;
        }

        public Criteria andResDesNumCargosLessThan(Integer value) {
            addCriterion("res_des_num_cargos <", value, "resDesNumCargos");
            return (Criteria) this;
        }

        public Criteria andResDesNumCargosLessThanOrEqualTo(Integer value) {
            addCriterion("res_des_num_cargos <=", value, "resDesNumCargos");
            return (Criteria) this;
        }

        public Criteria andResDesNumCargosIn(List<Integer> values) {
            addCriterion("res_des_num_cargos in", values, "resDesNumCargos");
            return (Criteria) this;
        }

        public Criteria andResDesNumCargosNotIn(List<Integer> values) {
            addCriterion("res_des_num_cargos not in", values, "resDesNumCargos");
            return (Criteria) this;
        }

        public Criteria andResDesNumCargosBetween(Integer value1, Integer value2) {
            addCriterion("res_des_num_cargos between", value1, value2, "resDesNumCargos");
            return (Criteria) this;
        }

        public Criteria andResDesNumCargosNotBetween(Integer value1, Integer value2) {
            addCriterion("res_des_num_cargos not between", value1, value2, "resDesNumCargos");
            return (Criteria) this;
        }

        public Criteria andResDesCodEstIsNull() {
            addCriterion("res_des_cod_est is null");
            return (Criteria) this;
        }

        public Criteria andResDesCodEstIsNotNull() {
            addCriterion("res_des_cod_est is not null");
            return (Criteria) this;
        }

        public Criteria andResDesCodEstEqualTo(Integer value) {
            addCriterion("res_des_cod_est =", value, "resDesCodEst");
            return (Criteria) this;
        }

        public Criteria andResDesCodEstNotEqualTo(Integer value) {
            addCriterion("res_des_cod_est <>", value, "resDesCodEst");
            return (Criteria) this;
        }

        public Criteria andResDesCodEstGreaterThan(Integer value) {
            addCriterion("res_des_cod_est >", value, "resDesCodEst");
            return (Criteria) this;
        }

        public Criteria andResDesCodEstGreaterThanOrEqualTo(Integer value) {
            addCriterion("res_des_cod_est >=", value, "resDesCodEst");
            return (Criteria) this;
        }

        public Criteria andResDesCodEstLessThan(Integer value) {
            addCriterion("res_des_cod_est <", value, "resDesCodEst");
            return (Criteria) this;
        }

        public Criteria andResDesCodEstLessThanOrEqualTo(Integer value) {
            addCriterion("res_des_cod_est <=", value, "resDesCodEst");
            return (Criteria) this;
        }

        public Criteria andResDesCodEstIn(List<Integer> values) {
            addCriterion("res_des_cod_est in", values, "resDesCodEst");
            return (Criteria) this;
        }

        public Criteria andResDesCodEstNotIn(List<Integer> values) {
            addCriterion("res_des_cod_est not in", values, "resDesCodEst");
            return (Criteria) this;
        }

        public Criteria andResDesCodEstBetween(Integer value1, Integer value2) {
            addCriterion("res_des_cod_est between", value1, value2, "resDesCodEst");
            return (Criteria) this;
        }

        public Criteria andResDesCodEstNotBetween(Integer value1, Integer value2) {
            addCriterion("res_des_cod_est not between", value1, value2, "resDesCodEst");
            return (Criteria) this;
        }

        public Criteria andFecNumCamIsNull() {
            addCriterion("fec_num_cam is null");
            return (Criteria) this;
        }

        public Criteria andFecNumCamIsNotNull() {
            addCriterion("fec_num_cam is not null");
            return (Criteria) this;
        }

        public Criteria andFecNumCamEqualTo(Integer value) {
            addCriterion("fec_num_cam =", value, "fecNumCam");
            return (Criteria) this;
        }

        public Criteria andFecNumCamNotEqualTo(Integer value) {
            addCriterion("fec_num_cam <>", value, "fecNumCam");
            return (Criteria) this;
        }

        public Criteria andFecNumCamGreaterThan(Integer value) {
            addCriterion("fec_num_cam >", value, "fecNumCam");
            return (Criteria) this;
        }

        public Criteria andFecNumCamGreaterThanOrEqualTo(Integer value) {
            addCriterion("fec_num_cam >=", value, "fecNumCam");
            return (Criteria) this;
        }

        public Criteria andFecNumCamLessThan(Integer value) {
            addCriterion("fec_num_cam <", value, "fecNumCam");
            return (Criteria) this;
        }

        public Criteria andFecNumCamLessThanOrEqualTo(Integer value) {
            addCriterion("fec_num_cam <=", value, "fecNumCam");
            return (Criteria) this;
        }

        public Criteria andFecNumCamIn(List<Integer> values) {
            addCriterion("fec_num_cam in", values, "fecNumCam");
            return (Criteria) this;
        }

        public Criteria andFecNumCamNotIn(List<Integer> values) {
            addCriterion("fec_num_cam not in", values, "fecNumCam");
            return (Criteria) this;
        }

        public Criteria andFecNumCamBetween(Integer value1, Integer value2) {
            addCriterion("fec_num_cam between", value1, value2, "fecNumCam");
            return (Criteria) this;
        }

        public Criteria andFecNumCamNotBetween(Integer value1, Integer value2) {
            addCriterion("fec_num_cam not between", value1, value2, "fecNumCam");
            return (Criteria) this;
        }

        public Criteria andCodIndCamIsNull() {
            addCriterion("cod_ind_cam is null");
            return (Criteria) this;
        }

        public Criteria andCodIndCamIsNotNull() {
            addCriterion("cod_ind_cam is not null");
            return (Criteria) this;
        }

        public Criteria andCodIndCamEqualTo(String value) {
            addCriterion("cod_ind_cam =", value, "codIndCam");
            return (Criteria) this;
        }

        public Criteria andCodIndCamNotEqualTo(String value) {
            addCriterion("cod_ind_cam <>", value, "codIndCam");
            return (Criteria) this;
        }

        public Criteria andCodIndCamGreaterThan(String value) {
            addCriterion("cod_ind_cam >", value, "codIndCam");
            return (Criteria) this;
        }

        public Criteria andCodIndCamGreaterThanOrEqualTo(String value) {
            addCriterion("cod_ind_cam >=", value, "codIndCam");
            return (Criteria) this;
        }

        public Criteria andCodIndCamLessThan(String value) {
            addCriterion("cod_ind_cam <", value, "codIndCam");
            return (Criteria) this;
        }

        public Criteria andCodIndCamLessThanOrEqualTo(String value) {
            addCriterion("cod_ind_cam <=", value, "codIndCam");
            return (Criteria) this;
        }

        public Criteria andCodIndCamLike(String value) {
            addCriterion("cod_ind_cam like", value, "codIndCam");
            return (Criteria) this;
        }

        public Criteria andCodIndCamNotLike(String value) {
            addCriterion("cod_ind_cam not like", value, "codIndCam");
            return (Criteria) this;
        }

        public Criteria andCodIndCamIn(List<String> values) {
            addCriterion("cod_ind_cam in", values, "codIndCam");
            return (Criteria) this;
        }

        public Criteria andCodIndCamNotIn(List<String> values) {
            addCriterion("cod_ind_cam not in", values, "codIndCam");
            return (Criteria) this;
        }

        public Criteria andCodIndCamBetween(String value1, String value2) {
            addCriterion("cod_ind_cam between", value1, value2, "codIndCam");
            return (Criteria) this;
        }

        public Criteria andCodIndCamNotBetween(String value1, String value2) {
            addCriterion("cod_ind_cam not between", value1, value2, "codIndCam");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}