package pe.com.j2techcon.bi.etl.domain;

import java.util.Date;

public class TCargoGuia {
    private Integer carGuiId;

    private Integer despId;

    private Integer cargId;

    private Integer carGuiCodMov;

    private Integer carGuiCodUbi;

    private Integer carGuiCodZon;

    private Integer carGuiCodPos;

    private Integer carGuiCodVer;

    private String carGuiDir;

    private String carGuiRef;

    private Date carGuiFecSal;

    private Date carGuiFecRetPro;

    private Date carGuiFecRetRea;

    private Date carGuiFecVer;

    private Integer carGuiCodEst;

    private Integer fecNumCam;

    private String codIndCam;

    public Integer getCarGuiId() {
        return carGuiId;
    }

    public void setCarGuiId(Integer carGuiId) {
        this.carGuiId = carGuiId;
    }

    public Integer getDespId() {
        return despId;
    }

    public void setDespId(Integer despId) {
        this.despId = despId;
    }

    public Integer getCargId() {
        return cargId;
    }

    public void setCargId(Integer cargId) {
        this.cargId = cargId;
    }

    public Integer getCarGuiCodMov() {
        return carGuiCodMov;
    }

    public void setCarGuiCodMov(Integer carGuiCodMov) {
        this.carGuiCodMov = carGuiCodMov;
    }

    public Integer getCarGuiCodUbi() {
        return carGuiCodUbi;
    }

    public void setCarGuiCodUbi(Integer carGuiCodUbi) {
        this.carGuiCodUbi = carGuiCodUbi;
    }

    public Integer getCarGuiCodZon() {
        return carGuiCodZon;
    }

    public void setCarGuiCodZon(Integer carGuiCodZon) {
        this.carGuiCodZon = carGuiCodZon;
    }

    public Integer getCarGuiCodPos() {
        return carGuiCodPos;
    }

    public void setCarGuiCodPos(Integer carGuiCodPos) {
        this.carGuiCodPos = carGuiCodPos;
    }

    public Integer getCarGuiCodVer() {
        return carGuiCodVer;
    }

    public void setCarGuiCodVer(Integer carGuiCodVer) {
        this.carGuiCodVer = carGuiCodVer;
    }

    public String getCarGuiDir() {
        return carGuiDir;
    }

    public void setCarGuiDir(String carGuiDir) {
        this.carGuiDir = carGuiDir == null ? null : carGuiDir.trim();
    }

    public String getCarGuiRef() {
        return carGuiRef;
    }

    public void setCarGuiRef(String carGuiRef) {
        this.carGuiRef = carGuiRef == null ? null : carGuiRef.trim();
    }

    public Date getCarGuiFecSal() {
        return carGuiFecSal;
    }

    public void setCarGuiFecSal(Date carGuiFecSal) {
        this.carGuiFecSal = carGuiFecSal;
    }

    public Date getCarGuiFecRetPro() {
        return carGuiFecRetPro;
    }

    public void setCarGuiFecRetPro(Date carGuiFecRetPro) {
        this.carGuiFecRetPro = carGuiFecRetPro;
    }

    public Date getCarGuiFecRetRea() {
        return carGuiFecRetRea;
    }

    public void setCarGuiFecRetRea(Date carGuiFecRetRea) {
        this.carGuiFecRetRea = carGuiFecRetRea;
    }

    public Date getCarGuiFecVer() {
        return carGuiFecVer;
    }

    public void setCarGuiFecVer(Date carGuiFecVer) {
        this.carGuiFecVer = carGuiFecVer;
    }

    public Integer getCarGuiCodEst() {
        return carGuiCodEst;
    }

    public void setCarGuiCodEst(Integer carGuiCodEst) {
        this.carGuiCodEst = carGuiCodEst;
    }

    public Integer getFecNumCam() {
        return fecNumCam;
    }

    public void setFecNumCam(Integer fecNumCam) {
        this.fecNumCam = fecNumCam;
    }

    public String getCodIndCam() {
        return codIndCam;
    }

    public void setCodIndCam(String codIndCam) {
        this.codIndCam = codIndCam == null ? null : codIndCam.trim();
    }
}