package pe.com.j2techcon.bi.etl.logic;

import java.util.List;

import pe.com.j2techcon.bi.etl.dao.TCargoMapper;
import pe.com.j2techcon.bi.etl.domain.TCargo;
import pe.com.j2techcon.bi.etl.domain.TCargoExample;

public class TCargoManager {

	private TCargoMapper tCargoMapper;
	
	
	public TCargoMapper gettCargoMapper() {
		return tCargoMapper;
	}

	public void settCargoMapper(TCargoMapper tCargoMapper) {
		this.tCargoMapper = tCargoMapper;
	}


	public int countByExample(TCargoExample example) {
		return tCargoMapper.countByExample(example);
	}


	public int deleteByExample(TCargoExample example) {
		return tCargoMapper.deleteByExample(example);
	}


	public int deleteByPrimaryKey(Integer cargId) {
		return tCargoMapper.deleteByPrimaryKey(cargId);
	}


	public int insert(TCargo record) {
		return tCargoMapper.insert(record);
	}


	public int insertSelective(TCargo record) {
		return tCargoMapper.insertSelective(record);
	}


	public List<TCargo> selectByExample(TCargoExample example) {
		return tCargoMapper.selectByExample(example);
	}


	public TCargo selectByPrimaryKey(Integer cargId) {
		return tCargoMapper.selectByPrimaryKey(cargId);
	}


	public int updateByExampleSelective(TCargo record, TCargoExample example) {
		return tCargoMapper.updateByExampleSelective(record, example);
	}


	public int updateByExample(TCargo record, TCargoExample example) {
		return tCargoMapper.updateByExample(record, example);
	}


	public int updateByPrimaryKeySelective(TCargo record) {
		return tCargoMapper.updateByPrimaryKeySelective(record);
	}


	public int updateByPrimaryKey(TCargo record) {
		return tCargoMapper.updateByPrimaryKey(record);
	}

}
